require("./__tests__/setup/teardown")();
console.log("DB Cleanup complete.")